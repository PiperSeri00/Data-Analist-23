/*Task 2: Descrivi la struttura delle tabelle che reputi utili e sufficienti a modellare lo scenario proposto tramite la sintassi DDL. 
Implementa fisicamente le tabelle utilizzando il DBMS SQL Server (o altro).
*/

CREATE DATABASE ToysGroup

CREATE TABLE Product 
(
    ProductKey INT,
    ProductName VARCHAR(25),
	ProductCategoryKey INT,
	ProducCategoryName VARCHAR(25),
    StandardCost DECIMAL (10, 2),
	FinishedGoodsFlag BIT,
	ListPrice DECIMAL (10, 2),
	DealerPrice DECIMAL (10, 2),
    StartDate DATE,
   CONSTRAINT PK_ProductKey PRIMARY KEY (ProductKey),
);

CREATE TABLE Region
(
	StateKey INT,
	StateName VARCHAR(25),
	RegionKey VARCHAR(3),
	RegionName VARCHAR(25),
	CONSTRAINT PK_StateKey PRIMARY KEY (StateKey),
	);

CREATE TABLE Sales
(
	ProductKey INT,
	StateKey INT,
	SalesOrderNumber INT,
	OrderDate DATE,
	Quantity INT,
	SalesAmount DECIMAL (10, 2),
	CONSTRAINT PK_SalesOrderNumber PRIMARY KEY (SalesOrderNumber),
	CONSTRAINT FK_ProductKey FOREIGN KEY (ProductKey) REFERENCES Product(ProductKey),
	CONSTRAINT FK_StateKey FOREIGN KEY (StateKey) REFERENCES Region(StateKey),
	);

/*Task 3: Popola le tabelle utilizzando dati a tua discrezione (sono sufficienti pochi record per tabella; riporta le query utilizzate) 
*/

INSERT INTO Product (ProductKey, ProductName, ProductCategoryKey, ProducCategoryName, StandardCost, FinishedGoodsFlag, ListPrice, DealerPrice, StartDate)
VALUES
(1, 'Bambola di plastica', 1, 'Bambole e Peluche', 7.4, 1, 8.88, 9.768, '2013-01-01'),
(2, 'Peluche', 1, 'Bambole e Peluche', 3, 1, 3.6, 3.96, '2014-04-02'),
(3, 'Set da costruzione', 2, 'Costruzioni', 2, 0, 2.4, 2.64, '2015-08-16'),
(4, 'Puzzle educativo', 3, 'Giochi da tavolo', 1.7, 1, 2.04, 2.244, '2016-10-17'),
(5, 'Taboo', 3, 'Giochi da tavolo', 12.5, 1, 15, 16.5, '2017-02-05'),
(6, 'Auto telecomandata', 4, 'Giocattoli elettronici', 11.3, 1, 13.56, 14.916, '2018-05-21'),
(7, 'PlayStation', 5, 'Console', 200, 1, 240, 264, '2019-07-30'),
(8, 'Nintendo Switch', 5, 'Console', 150, 1, 180, 198, '2020-11-10'),
(9, 'WII', 5, 'Console', 100, 0, 120, 132, '2021-03-22'),
(10, 'Libro interattivo', 6, 'Libri', 3.4, 1, 4.08, 4.488, '2022-05-12');

INSERT INTO Region (StateKey, StateName, RegionKey, RegionName)
VALUES
(1, 'Italy', 'EU3', 'Southern Europe'),
(2, 'France', 'EU2', 'Central Europe'),
(3, 'Germany', 'EU2', 'Central Europe'),
(4, 'Spain', 'EU3', 'Southern Europe'),
(5, 'Norway', 'EU1', 'Northern Europe'),
(6, 'USA', 'US1', 'North America'),
(7, 'Canada', 'US1', 'North America'),
(8, 'Japan', 'AS1', 'East'),
(9, 'China', 'AS1', 'East'),
(10, 'Australia', 'OC1', 'Oceania');

INSERT INTO Sales (ProductKey, StateKey, SalesOrderNumber, OrderDate, Quantity, SalesAmount)
VALUES
(1, 1, 1, '2022-02-01', 1, 8.88),
(4, 1, 2, '2022-03-21', 3, 6.12),
(3, 3, 3, '2022-05-13', 5, 12),
(3, 5, 4, '2022-11-18', 3, 7.2),
(5, 5, 5, '2022-12-22', 2, 30),
(6, 6, 6, '2023-03-03', 1, 13.56),
(7, 6, 7, '2023-07-05', 1, 240),
(7, 8, 8, '2023-10-17', 1, 240),
(7, 10, 9, '2023-11-11', 2, 480),
(10, 10, 10, '2023-12-08', 2, 8.16);

SELECT * FROM Product
SELECT * FROM Region
SELECT * FROM Sales