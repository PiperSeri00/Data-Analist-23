/* 
Task 4: Dopo aver popolate le tabelle, scrivi delle query utili a:
1)	Verificare che i campi definiti come PK siano univoci. In altre parole, scrivi una query per determinare l�univocit� dei valori di ciascuna PK (una query per tabella implementata).
*/

SELECT COUNT(*), ProductKey
FROM Product
GROUP BY ProductKey
HAVING COUNT(*) > 1

SELECT COUNT(*), StateKey
FROM Region
GROUP BY StateKey
HAVING COUNT(*) > 1

SELECT COUNT(*), SalesOrderNumber
FROM Sales
GROUP BY SalesOrderNumber
HAVING COUNT(*) > 1

--2)Esporre l�elenco delle transazioni indicando nel result set il codice documento, la data, il nome del prodotto, la categoria del prodotto, 
--il nome dello stato, il nome della regione di vendita e un campo booleano valorizzato in base alla condizione che siano passati pi� di 180 giorni 
--dalla data vendita o meno (>180 -> True, <= 180 -> False)

SELECT s.SalesOrderNumber, s.OrderDate, p.ProductName, p.ProductCategoryKey, r.StateName, r.RegionName,
CASE
		WHEN DATEDIFF (day, s.OrderDate, GETDATE()) > 180 THEN 'True'
		WHEN DATEDIFF (day, s.OrderDate, GETDATE()) <= 180 THEN 'False'
		END AS '180+day'
FROM Sales AS s
INNER JOIN Product AS p
ON s.ProductKey = p.ProductKey
INNER JOIN Region AS r
ON s.StateKey = r.StateKey
ORDER BY OrderDate

--3)	Esporre l�elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno. 

SELECT p.ProductKey, p.ProductName, YEAR(s.OrderDate) AS Year, SUM(s.SalesAmount) AS TotSalesYear
FROM Sales AS s
LEFT JOIN Product AS p
ON p.ProductKey = s.ProductKey
GROUP BY p.ProductKey, p.ProductName, YEAR(s.OrderDate)
ORDER BY YEAR(s.OrderDate)

--4)	Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.

SELECT r.StateName, YEAR(s.OrderDate) AS Year, SUM(s.SalesAmount) AS TotSalesYear
FROM Sales AS s
LEFT JOIN Region AS r
ON s.StateKey = r.StateKey
GROUP BY r.StateName, YEAR(s.OrderDate)
ORDER BY YEAR(s.OrderDate) DESC, SUM(s.SalesAmount) DESC

--5)	Rispondere alla seguente domanda: qual � la categoria di articoli maggiormente richiesta dal mercato?
--La Categoria di prodotti maggiormente venduta � quella delle Console

SELECT p.ProductName, p.ProducCategoryName, COUNT(s.Quantity) AS Quantity, SUM(s.SalesAmount) as TotalSales
FROM Sales as s
LEFT JOIN Product as p
ON s.ProductKey = p.ProductKey
GROUP BY p.ProductName, p.ProducCategoryName
ORDER BY COUNT(s.Quantity) DESC

--6)	Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti.
--per rispondere bisogna verificare i productkey non presenti nella tabella Sales, i due approcci sono query innestata con where o join

SELECT ProductName
FROM Product
WHERE ProductKey NOT IN(
		SELECT ProductKey
        FROM Sales)
    
SELECT p.ProductName
FROM Product AS p
LEFT JOIN Sales AS s 
ON p.ProductKey = s.ProductKey
WHERE s.ProductKey IS NULL

--7)	Esporre l�elenco dei prodotti cona la rispettiva ultima data di vendita (la data di vendita pi� recente).

-- Trova l'elenco dei prodotti con la rispettiva ultima data di vendita

SELECT p.ProductKey, p.ProductName, MAX(s.OrderDate) AS LastSale
FROM Product AS p
LEFT JOIN Sales s 
ON p.ProductKey = s.ProductKey
GROUP BY p.ProductKey, p.ProductName
HAVING MAX(s.OrderDate) IS NOT NULL
ORDER BY MAX(s.OrderDate) DESC

--8)	Creare una vista sui prodotti in modo tale da esporre una �versione denormalizzata� delle informazioni utili (codice prodotto, nome prodotto, nome categoria)

CREATE VIEW InfoProdotto AS(
	SELECT ProductKey, ProductName,	ProductCategoryKey, ProducCategoryName 
	FROM Product)

--9)	Creare una vista per restituire una versione �denormalizzata� delle informazioni geografiche

CREATE VIEW InfoGeo AS(
	SELECT StateKey, StateName, RegionKey, RegionName
	FROM Region)

--10)	Esercizio opzionale: ottenute le viste per la costruzione delle dimensioni di analisi prodotto (punto 7)  e area geografica (punto 8),
--implementa un modello logico in Power Query e costruisci un report per l�analisi delle vendite

--EXCEL